# Задача 3. Список цифр числа

number = int(input('Введите число: '))
num = [int(i) for i in str(number)]
print(num)
