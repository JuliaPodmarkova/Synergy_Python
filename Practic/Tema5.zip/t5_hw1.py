# Задача 1. Список имен

names = input('Введите имена через пробел: ').split()

print(sorted(names))
